Zlib 1.2.3 + MiniZip Dynamic Library
based on code by Gilles Vollant

Building instructions for the Linux version 
==============================================

This directory contains a Makefile that builds zlib and minizip 
using GCC.

You don't need to build these projects yourself. 
You can download the binaries from:
  http://olegykj.sourceforge.net/

More information can be found at this site.


Build instructions for GCC
--------------------------------------------------
- Uncompress current zlib, including all contrib/* files
- cd contrib\linux containing Makefile
- make

Additional notes
----------------
- This library, named zlibapi.so, is renamed because the 
version of zlib.so included in Linux does not contain 
the minizip module.


Oleg Kobchenko
olegyk@yahoo.com
